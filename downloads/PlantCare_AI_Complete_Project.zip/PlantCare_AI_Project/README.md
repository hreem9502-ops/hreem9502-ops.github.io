# PlantCare AI

**Smart Plant Identification, Disease Detection & Care Assistant**

A complete, working, AI-powered web application developed as a university group project.

Take a photo of any plant — PlantCare AI identifies the species, checks visible leaf
symptoms for possible diseases, and provides a species-specific care guide
(watering, sunlight, soil, temperature and more). Every analysis can be saved to
your personal **My Plants** history.

**Project team:**

| # | Student Name |
|---|--------------|
| 1 | Jory Mohiuddin |
| 2 | Dima Sami |
| 3 | Rona Sharif |
| 4 | Sadeem Al-Thaqafi |
| 5 | Warda Al-Barqi |

> Fill in your academic details (university, course, instructor, student IDs) in the
> presentation cover slide and in the Word documents — they contain clearly marked
> editable placeholder fields.

---

## 1. What is inside this package

```
PlantCare_AI_Project/
│
├── application/            ← The complete Next.js web application (source code)
│   ├── src/                   app pages, API routes, UI components, AI services
│   ├── prisma/schema.prisma    database schema (SQLite "PlantScan" model)
│   ├── public/                 static assets (logo, hero image)
│   ├── uploads/                server folder that stores uploaded photos
│   ├── .env.example            environment configuration template (NO real keys)
│   ├── package.json            dependencies + scripts (replaces requirements.txt)
│   └── ...                     tsconfig / tailwind / eslint configuration
│
├── presentation/
│   ├── PlantCare_AI_Presentation.pptx   15-slide academic presentation
│   └── PlantCare_AI_Presentation.pdf    printable PDF version
│
├── documentation/
│   ├── Project_Report.docx              full academic report
│   ├── Installation_Guide.docx          step-by-step installation guide (with screenshots)
│   ├── Presentation_Speaker_Notes.docx  per-student speaking scripts + Q&A
│   └── Student_Task_Distribution.docx   responsibilities of the five students
│
├── screenshots/            ← genuine screenshots of the running application
├── README.md               ← this file
└── START_HERE.txt          ← quick-start instructions
```

**Technology note:** the application is implemented with a modern full-stack
JavaScript/TypeScript architecture (Next.js 16 + React + TypeScript, with SQLite
via Prisma) instead of Python/Flask. This was a deliberate engineering choice:
one framework serves both the interface and the backend API, keeps deployment
simple (a single `bun install && bun run dev`), and still delivers every required
function — file upload, camera capture, AI vision integration, and the local
database. `package.json` replaces `requirements.txt`.

---

## 2. Main features

- **Plant identification** — common + scientific name, category, description,
  characteristics, growing environment, and confidence when the model provides it.
- **Disease detection** — observed symptoms (yellowing, brown spots, wilting,
  dry edges...), possible problems with *cautious* wording, likely causes,
  recommended actions and prevention advice. A photo is never a confirmed
  diagnosis — the app always says so.
- **Care guide** — watering, sunlight, soil, temperature, humidity,
  fertilization, pruning and maintenance, matched to the identified species.
- **My Plants history** — every analysis can be saved, reopened and deleted
  (SQLite database).
- **Camera capture** — take a photo directly with the device camera, or upload
  JPG / JPEG / PNG / WEBP files up to 10 MB.
- **Bilingual interface** — English primary + Arabic switch with full RTL support.
- **Dark mode**, responsive layout (mobile / tablet / desktop), loading
  animations and clear error messages.
- **Demo Mode** — the app always remains usable, even with no API key at all.

---

## 3. Technology stack

| Layer | Technology |
|---|---|
| Framework | Next.js 16 (App Router) + React 19 + TypeScript 5 |
| UI | Tailwind CSS 4, shadcn/ui, Lucide icons, Framer Motion |
| Backend | Next.js API routes (`/api/analyze`, `/api/plants`, `/api/config`) |
| AI | Gemini Vision API (optional key) → built-in Vision AI → Demo Mode |
| Optional AI | Plant.id identification API (optional key) |
| Database | SQLite via Prisma ORM |
| Runtime | Bun (or Node.js 18+) |

---

## 4. Installation

Requirements: **Bun 1.1+** (or Node.js 18+ with npm) and a modern browser.

```bash
# 1) enter the application folder
cd PlantCare_AI_Project/application

# 2) install dependencies
bun install

# 3) create your environment file
cp .env.example .env

# 4) create the SQLite database (creates db/custom.db from the schema)
bun run db:push

# 5) start the application
bun run dev
```

Then open **http://localhost:3000** in your browser.

(Using npm instead of Bun: `npm install`, `npx prisma db push`, `npm run dev`.)

---

## 5. Configuration (API keys)

Copy `.env.example` to `.env` and fill in what you need. Keys are only read
**server-side** and are never exposed to the browser.

```env
DATABASE_URL=file:./db/custom.db   # adjust to your path

# Optional — real AI plant analysis via Google Gemini:
GEMINI_API_KEY=your_key_here      # get one at https://ai.google.dev/
GEMINI_MODEL=gemini-1.5-flash

# Optional — supplementary identification via Plant.id:
PLANT_ID_API_KEY=your_key_here    # get one at https://plant.id/
```

**How the AI provider chain works:**

1. If `GEMINI_API_KEY` is set → the app calls the **Gemini Vision API**.
2. If Gemini is unavailable (or not configured) → the built-in **Vision AI**
   provider is used (this produced the live demo analyses in our environment).
3. If no provider is reachable → **Demo Mode** returns clearly-labeled sample
   data so the application never breaks.

**Demo Mode** can also be enabled manually with the toggle in the app header —
useful for a classroom demo without API costs. Demo results are always visibly
marked as sample data.

---

## 6. Using the application

1. Click **Start Plant Analysis** (or **Scan Plant**).
2. Upload a plant photo, drag & drop one, or use **Take Photo with Camera**.
3. Click **Analyze Image** and wait for the AI analysis.
4. Read the three tabs: **Identification**, **Health & Disease**, **Care Guide**.
5. Click **Save to My Plants** to keep the report in your history.
6. Open **My Plants** to view saved records, reopen the full report, or delete it.

---

## 7. Troubleshooting

| Problem | Solution |
|---|---|
| Port 3000 already in use | Stop the other process, or change the port in `package.json` (`next dev -p 3001`) |
| Database errors / empty history | Re-run `bun run db:push` and restart the app |
| Camera not working | Allow camera permission; browsers require HTTPS or localhost for camera access |
| Analysis fails / API errors | Check `GEMINI_API_KEY` validity and quota; the app automatically falls back to Demo Mode |
| Invalid file error | Use JPG, JPEG, PNG or WEBP images under 10 MB |
| Arabic text direction | Use the language button in the header (EN / ع) |

---

## 8. Testing (what was actually executed)

The application was tested end-to-end with an automated headless browser against
the running app in November 2025. All of the following passed:

- Homepage loads with all sections
- JPG and PNG image uploads accepted; invalid file (.txt) rejected with a clear error
- Image preview, remove and replace work
- **Real AI analysis executed** with the built-in vision model: a Peace Lily photo
  was correctly identified; a diseased tomato photo produced symptom detection
  ("may indicate early blight") with an honest uncertainty note
- Care guide, saving to history, viewing records, deleting records
- Mobile layout at 375x812 verified
- Missing API key → Demo Mode fallback works and is clearly labeled
- Non-plant image (a cat photo) → correctly refused as "not a plant"
- Arabic RTL interface and dark mode toggle verified

**Honesty statement:** the Gemini Vision API integration code is fully
implemented and documented but was *not* live-tested (no Gemini key was
available in the development environment). The live analyses shown in our
screenshots were produced by the built-in Vision AI provider of the deployment
environment. Demo Mode data is always labeled as sample data, never presented
as real AI output.

---

## 9. References

- Plant.id — https://plant.id/
- Google AI for Developers — https://ai.google.dev/
- TensorFlow — https://www.tensorflow.org/
- Food and Agriculture Organization (FAO) — https://www.fao.org/
- Next.js documentation — https://nextjs.org/docs
- Prisma ORM — https://www.prisma.io/docs
- Tailwind CSS — https://tailwindcss.com/docs
- shadcn/ui — https://ui.shadcn.com/

---

PlantCare AI — academic project, for educational use.
