import type { Metadata } from "next";
import { Fraunces, Inter, Noto_Kufi_Arabic } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/sonner";

const displayFont = Fraunces({
  variable: "--font-fraunces",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
});

const bodyFont = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const arabicFont = Noto_Kufi_Arabic({
  variable: "--font-noto-kufi-arabic",
  subsets: ["arabic"],
  weight: ["400", "500", "700"],
});

export const metadata: Metadata = {
  title: "PlantCare AI — Smart Plant Identification, Disease Detection & Care Assistant",
  description:
    "Take a photo of any plant and let AI identify the species, detect visible disease symptoms, and provide a complete care guide. Academic project by Jory Mohiuddin, Dima Sami, Rona Sharif, Sadeem Al-Thaqafi and Warda Al-Barqi.",
  keywords: [
    "PlantCare AI",
    "plant identification",
    "plant disease detection",
    "AI plant care",
    "botany",
    "smart agriculture",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning>
      <body
        className={`${displayFont.variable} ${bodyFont.variable} ${arabicFont.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} disableTransitionOnChange>
          {children}
          <Toaster richColors closeButton />
        </ThemeProvider>
      </body>
    </html>
  );
}
